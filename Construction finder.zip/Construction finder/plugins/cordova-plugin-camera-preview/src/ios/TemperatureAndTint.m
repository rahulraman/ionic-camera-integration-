#include "TemperatureAndTint.h"

@implementation TemperatureAndTint
@synthesize mode;
@synthesize minTemperature;
@synthesize maxTemperature;
@synthesize tint;

@end