import { NgModule } from '@angular/core';
import { SortPipe } from './sort/sort';
@NgModule({
	declarations: [SortPipe],
	imports: [],
	exports: [SortPipe]
})
export class PipesModule {}
