import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';
import { HttpModule } from '@angular/http';
import { Base64 } from '@ionic-native/base64';
import { Media } from '@ionic-native/media';
import { File } from '@ionic-native/file';
import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { DropboxProvider } from '../providers/dropbox/dropbox';
import { Camera } from '@ionic-native/camera';
import { DropboxtestPage } from '../pages/dropboxtest/dropboxtest';
import { ConstructionsitesPage } from '../pages/constructionsites/constructionsites';
import { SortPipe } from '../pipes/sort/sort';
import { AreaconstructionPage } from '../pages/areaconstruction/areaconstruction';
import { DokulingmapPage } from '../pages/dokulingmap/dokulingmap';
import { CameraPreview} from '@ionic-native/camera-preview';
import { CameraviewPage } from '../pages/cameraview/cameraview';
import { Geolocation } from '@ionic-native/geolocation';
import { LocalstorageProvider } from '../providers/localstorage/localstorage';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
  declarations: [
    MyApp,
    HomePage,
    ConstructionsitesPage,
    DropboxtestPage,
    AreaconstructionPage,
    SortPipe,
    CameraviewPage,
    DokulingmapPage
  ],
  imports: [
    BrowserModule,
    HttpModule,
    HttpClientModule,
    IonicModule.forRoot(MyApp, {
      backButtonText: '',
      iconMode: 'ios',
      modalEnter: 'modal-slide-in',
      modalLeave: 'modal-slide-out',
      tabsPlacement: 'bottom',
      pageTransition: 'ios-transition'
    })
  ],

  bootstrap: [IonicApp],
  entryComponents:[
    MyApp,
    HomePage,
    ConstructionsitesPage,
    AreaconstructionPage,
    DokulingmapPage,
    CameraviewPage,
    DropboxtestPage
  ],

  providers: [
    StatusBar,
    SplashScreen,
    Base64,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    DropboxProvider,
    Media,
    CameraPreview,
    Camera,
    Geolocation,
    File,
    LocalstorageProvider
  ],

  schemas: [
    CUSTOM_ELEMENTS_SCHEMA,
    NO_ERRORS_SCHEMA
  ]
})

export class AppModule {}
