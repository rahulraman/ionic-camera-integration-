import { Component } from '@angular/core';
import { Platform } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { HomePage } from '../pages/home/home';
import { DropboxtestPage } from '../pages/dropboxtest/dropboxtest';
import { ConstructionsitesPage } from '../pages/constructionsites/constructionsites';
import { CameraviewPage } from '../pages/cameraview/cameraview';
import { Geolocation } from '@ionic-native/geolocation';
import { LocalstorageProvider } from '../providers/localstorage/localstorage';


@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  // rootPage:any = DropboxtestPage;
  // rootPage:any = ConstructionsitesPage;
  
  rootPage:any = CameraviewPage;
  // rootPage:any = ConstructionsitesPage;
  
  constructor(
    platform: Platform,
    private localdata : LocalstorageProvider,
     private geolocation: Geolocation,
     statusBar: StatusBar, 
     splashScreen: SplashScreen) 
     {
    platform.ready().then(() => {

      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      statusBar.styleDefault();
      statusBar.backgroundColorByHexString('#828896');
      splashScreen.hide();
      this.GetCurrentLocation();
    }); 
  }
  GetCurrentLocation() {
    this.geolocation.getCurrentPosition().then((resp) => 
    {
      this.localdata.storeCurrentLocation(resp.coords.latitude ,resp.coords.longitude);
      // console.log("Latitude => ",resp.coords.latitude);
      // console.log("Longitude => ", resp.coords.longitude);
     }).catch((error) => {
       alert(JSON.stringify(error));
     });

    let watch = this.geolocation.watchPosition();
     watch.subscribe((data) => 
     {
      this.localdata.storeCurrentLocation(data.coords.latitude ,data.coords.longitude);

      // console.log("Watch Position => ",data.coords);
      
     });
  }

}
  