import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams, Platform, AlertController, LoadingController } from 'ionic-angular';
import { CameraPreview, CameraPreviewPictureOptions, CameraPreviewOptions, CameraPreviewDimensions } from '@ionic-native/camera-preview';
import { DropboxProvider } from '../../providers/dropbox/dropbox';
import { Slides } from 'ionic-angular';

/**
 * Generated class for the CameraviewPage page.
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({ 
  selector: 'page-cameraview',
  templateUrl: 'cameraview.html',
})
export class CameraviewPage {
  @ViewChild(Slides) slides: Slides;

  picture:any;
  folders: any; 
  categories:any =[];
  imageUploadPath:any;
  private cameraPreviewOpts = {
    x: 0,
    y: 80,
    width: window.screen.width,
     height:window.screen.height / 1.6,
   camera: "rear", tapPhoto: true, previewDrag: false, toBack: true
    };

  constructor(
    public navCtrl: NavController, 
    private alertCtrl: AlertController,
    private cameraPreview: CameraPreview,
    public dropbox: DropboxProvider,
    public loadingCtrl: LoadingController,
    platform: Platform,
    public navParams: NavParams
    )
   {
      platform.ready().then(() =>
      {
  this.getDropboxData();
        // this.slides.freeMode = true;
    this.initializePreview(); 
  }); 
  }

  initializePreview() 
  {
    this.cameraPreview.startCamera(this.cameraPreviewOpts).then(
      (res) => {
        console.log(res)
      },
      (err) => {
        console.log(err)
        alert(err);
      });
  }

flachOn()
{

  this.cameraPreview.getSupportedFlashModes().then((data: any)=> {
    console.log("GetSupportedFlashModes => " , data );
  });
  this.cameraPreview.setFlashMode( this.cameraPreview.FLASH_MODE.ON);
}

takePhoto()
{
  const pictureOpts: CameraPreviewPictureOptions = {
    width: 1280,
    height: 1280,
    quality: 50
  }
  // take a picture
  this.cameraPreview.takePicture(pictureOpts).then((imageData) => {
    this._base64ToArrayBuffer(imageData);
    this.picture = 'data:image/jpeg;base64,' + imageData;
  }, 
  (err) => {
    console.log(err);
    alert(JSON.stringify(err));
    this.picture = 'assets/img/test.jpg';
  }
  );
}
_base64ToArrayBuffer(base64) {
  let loading = this.loadingCtrl.create({
    content: 'uploading image to Dropbox...'
  });
  loading.present();
  var binary_string =  window.atob(base64);
  var len = binary_string.length;
  var bytes = new Uint8Array( len );
  for (var i = 0; i < len; i++){
      bytes[i] = binary_string.charCodeAt(i);
  }
  // alert('buffer => '+JSON.stringify(bytes));
   this.uploadImage(bytes.buffer ,this.imageUploadPath);
  loading.dismiss(); 

}
uploadImage(imageurl , imageUploadPath) {
  let loading = this.loadingCtrl.create({
    content: 'uploading image to Dropbox...'
  });
  loading.present();

this.dropbox.uploadFile(imageurl, imageUploadPath).subscribe(response => 
  {
      console.log('response',JSON.stringify(response));
      loading.dismiss();
      this.navCtrl.push("ConstructionsitesPage");
       
  },  
  err =>
  {
    loading.dismiss(); 
    alert(JSON.stringify(err));
    console.log('Error',JSON.stringify(err));
  });
}

cresteNewCategory()
{
  let alert = this.alertCtrl.create({
    title: 'Add create new category',
    inputs: [
      {
        name: 'categoryname',
        placeholder: 'Category name'
      }
    ],
    buttons: [
      {
        text: 'Cancel',
        role: 'cancel',
        handler: data => {
          console.log('Cancel clicked'); 
          // console.log('slides length => ', this.slides.length());
        }
      },
      {
        text: 'Create',
        handler: data =>
        {
          console.log('data =>', data.categoryname);
          this.createCategory(data.categoryname);
        }
      }
    ]
  });
  alert.present();
}
ionViewDidLoad()
{}

getDropboxData() 
{
  this.dropbox.setAccessToken("g7iHQVRCiVAAAAAAAAAACmAkAuB7W8O9xcl_KtcZazx48whie18H8rMbk4sKY1dV");
  this.folders = [];
  let loading = this.loadingCtrl.create({
    content: 'Syncing from Dropbox...'
  });
  loading.present();
  this.dropbox.getFolders().subscribe(data => {
    this.folders = data.entries[0];  
    console.log('folders new=> ',  this.folders.path_lower); 
    this.dropbox.getFolders(this.folders.path_lower).subscribe(async data => {
        this.categories = data.entries;
      console.log('category => ', data.entries );
      loading.dismiss();

    setTimeout( () => { 
    console.log('slides length => ', this.slides.length());
     this.slides.slideTo(this.slides.length() - 1 , 500 , true);
    }, 700);
    }, 
    (err) => 
    {
      console.log(err);
    });
    loading.dismiss();
  }, (err) => {
    console.log(err);
  });
}

createCategory (categoryname) {

  if(categoryname) 
  {
    this.folders.path_lower
    console.log("folders.path_lower => " , this.folders.path_lower+'/'+categoryname);
    this.dropbox.createFolder(this.folders.path_lower+'/'+categoryname).subscribe(data => {
      this.getDropboxData();
    },
    error => {
      alert(JSON.stringify(error))
    })
  }
  else
  {
    alert('Category name required');
    console.log("Its null else")
  }
}

slideChanged()
{
   if(this.slides.getActiveIndex() == this.slides.length()) {
    console.log('getActiveIndex() if => ', this.slides.getActiveIndex());
   } 
   else
   {
    // console.log('getActiveIndex() else => ', this.slides.getActiveIndex());
  console.log('Current categories', this.categories[this.slides.getActiveIndex()].path_lower); 
  this.imageUploadPath = this.categories[this.slides.getActiveIndex()].path_lower;
   }
  }
}
