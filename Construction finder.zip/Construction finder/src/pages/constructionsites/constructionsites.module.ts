import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ConstructionsitesPage } from './constructionsites';

@NgModule({
  declarations: [
    ConstructionsitesPage,
  ],
  imports: [
    IonicPageModule.forChild(ConstructionsitesPage),
  ],
})
export class ConstructionsitesPageModule {}
