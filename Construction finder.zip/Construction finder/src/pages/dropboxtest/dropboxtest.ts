import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
/**
 * Generated class for the DropboxtestPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
 
@IonicPage()
@Component({
  selector: 'page-dropboxtest',
  templateUrl: 'dropboxtest.html',
})
export class DropboxtestPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) 
  {
    
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad DropboxtestPage');
  } 
  testCall() {
          var img = document.createElement('img');
          img.src = window.URL.createObjectURL('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQNiLWxMO9Rzv-JxNEg-5EyFJ8qH9uwKF5syg4XFssh7L2MAZvsFA');
          document.getElementById('results').appendChild(img);
  }
}