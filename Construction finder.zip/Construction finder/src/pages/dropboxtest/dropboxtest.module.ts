import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DropboxtestPage } from './dropboxtest';

@NgModule({
  declarations: [
    DropboxtestPage,
  ],
  imports: [
    IonicPageModule.forChild(DropboxtestPage),
  ],
})
export class DropboxtestPageModule {}
