import { Component } from '@angular/core';
import { NavController, LoadingController, AlertController } from 'ionic-angular';
import {  DropboxProvider } from '../../providers/dropbox/dropbox';
import { DomSanitizer } from '@angular/platform-browser';
import { Base64 } from '@ionic-native/base64';
import { Camera, CameraOptions } from '@ionic-native/camera';
import { normalizeURL } from 'ionic-angular';
import { ConstructionsitesPage } from '../constructionsites/constructionsites';
import { DokulingmapPage } from '../dokulingmap/dokulingmap';


@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {  

  depth: number = 0; 
  folders: any; 
  imagedata: any;
  testimage = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQNiLWxMO9Rzv-JxNEg-5EyFJ8qH9uwKF5syg4XFssh7L2MAZvsFA";

  constructor(public navCtrl: NavController, 
    public dropbox: DropboxProvider, 
    private base64: Base64,
    private alertCtrl: AlertController,
    private camera: Camera,
    public loadingCtrl: LoadingController,
    private sanitizer: DomSanitizer) 
    {}

  ionViewDidLoad()
  {
    // this.convet(this.testimage);
      this.dropbox.setAccessToken("g7iHQVRCiVAAAAAAAAAACmAkAuB7W8O9xcl_KtcZazx48whie18H8rMbk4sKY1dV");
      this.folders = [];
      let loading = this.loadingCtrl.create({
        content: 'Syncing from Dropbox...'

      });

      loading.present();
      this.dropbox.getFolders().subscribe(data => {
        this.folders = data.entries;
        console.log('folders => ', this.folders);
        loading.dismiss();
      }, (err) => {
        console.log(err);
      });
  }

  openFolder(path){
    let loading = this.loadingCtrl.create({
      content: 'Syncing from Dropbox...'
    });
    loading.present();
    this.dropbox.getFolders(path).subscribe(data => {
      console.log("folder data => ", data);
      this.folders = data.entries;
      this.depth++;
      loading.dismiss();
    }, err => {
      console.log(err);
    });
  }

  goBack() {
    this.imagedata = '';
    let loading = this.loadingCtrl.create({
      content: 'Syncing from Dropbox...'
    });
    loading.present();
    this.dropbox.goBackFolder().subscribe(data => {
      this.folders = data.entries;
      this.depth--;
      loading.dismiss();
    }, err => {
      console.log(err);
    });
  }
  
  downloadfile( path_lower) {
    let loading = this.loadingCtrl.create({
      content: 'Getting image from Dropbox...'
    });
    loading.present();
    this.dropbox.downloadFile( path_lower).subscribe( (data: any) => {
      console.log('File data => ', data);
      // this.imagedata = data._body;
      this.getImgContent(data);
      loading.dismiss();
    });
  }
  getImgContent(image) 
  {
    this.imagedata  = image; 
    console.log('imagedata => ', this.imagedata); 
}

openCamera() {
  const options: CameraOptions = {
    quality: 50,
    destinationType: this.camera.DestinationType.DATA_URL,
    encodingType: this.camera.EncodingType.JPEG,
    mediaType: this.camera.MediaType.PICTURE
  }
  this.camera.getPicture(options).then((imageData) => 
  {
    // this.uploadImage(imageData);
    // console.log("camera imagedata => ", imageData);
    // console.log("camera normalizeURL => ", normalizeURL(imageData));
    this._base64ToArrayBuffer(imageData);
   // imageData is either a base64 encoded string or a file URI
   // If it's base64 (DATA_URL):
   let base64Image = 'data:image/jpeg;base64,' + imageData;
  }, (err) => {
   // Handle error
  });
}

  _base64ToArrayBuffer(base64) {
    let loading = this.loadingCtrl.create({
      content: 'uploading image to Dropbox...'
    });
    loading.present();
    var binary_string =  window.atob(base64);
    var len = binary_string.length;
    var bytes = new Uint8Array( len );
    for (var i = 0; i < len; i++){
        bytes[i] = binary_string.charCodeAt(i);
    }
    // alert('buffer => '+JSON.stringify(bytes));
     this.uploadImage(bytes.buffer);
    loading.dismiss();

}
uploadImage(imageurl) {
  // this.dropbox.uploadFile(imageurl);
  }

  deleteFile(filePath){
    let alert = this.alertCtrl.create({
      title: 'Delete',
      message: 'Do you want to delete this file ?',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Ok',
          handler: () => {
            let loading = this.loadingCtrl.create({
              content: 'Deleting image from Dropbox...'
            });
            loading.present();

            this.dropbox.deleteFile(filePath).subscribe( data => {
              
              console.log("Delete Data =>",data);
              this.goBack();
              loading.dismiss();
            });
          }
        }
      ]
    });
    alert.present();
  }
  onInput(e) {
    console.log(' onInput Event => ', e)
  }
  onCancel(e) {
    console.log(' onCancel Event => ', e)

  }
  startPage() {
    this.navCtrl.push(ConstructionsitesPage);
  }
  goTomap() {
    this.navCtrl.push(DokulingmapPage); 
  }

}
