import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController } from 'ionic-angular';
import { DropboxProvider } from '../../providers/dropbox/dropbox';

/**
 * Generated class for the ImagelistPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-imagelist',
  templateUrl: 'imagelist.html',
})
export class ImagelistPage {
  sitename:any;
  folders = [];
  imagedata:any;

  constructor(public navCtrl: NavController, 
    public dropbox: DropboxProvider,
    public loadingCtrl: LoadingController,
    public navParams: NavParams) 
  {
    this.sitename =  this.navParams.get('path');
    this.getDropboxData()
  }

  getDropboxData() 
  {
    this.dropbox.setAccessToken("g7iHQVRCiVAAAAAAAAAACmAkAuB7W8O9xcl_KtcZazx48whie18H8rMbk4sKY1dV");
    let loading = this.loadingCtrl.create({
      content: 'Syncing from Dropbox...'
    });
    loading.present();
    this.dropbox.getFolders(this.sitename).subscribe(data => {
      this.folders = data.entries;
      console.log('folders new=> ',  this.folders);  
      loading.dismiss();
    }, (err) => {
      console.log(err);
    });
  }

  downloadfile( path_lower) {
    let loading = this.loadingCtrl.create({
      content: 'Getting image from Dropbox...'
    });
    loading.present();
    this.dropbox.downloadFile( path_lower).subscribe( (data: any) => {
      console.log('File data => ', data);
      // this.imagedata = data._body;
      this.getImgContent(data);
      loading.dismiss();
    });
  }
  getImgContent(image) 
  {
    this.imagedata  = image; 
    console.log('imagedata => ', this.imagedata); 
}
  ionViewDidLoad() {
    console.log('ionViewDidLoad ImagelistPage');
  }

}
