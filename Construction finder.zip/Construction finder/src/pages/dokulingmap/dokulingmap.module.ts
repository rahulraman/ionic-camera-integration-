import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DokulingmapPage } from './dokulingmap';

@NgModule({
  declarations: [
    DokulingmapPage,
  ],
  imports: [
    IonicPageModule.forChild(DokulingmapPage),
  ],
})
export class DokulingmapPageModule {}
