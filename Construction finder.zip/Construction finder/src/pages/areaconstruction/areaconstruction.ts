import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController } from 'ionic-angular';
import { DropboxProvider } from '../../providers/dropbox/dropbox';

/**
 * Generated class for the AreaconstructionPage page.
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

  
@IonicPage()

@Component({
  selector: 'page-areaconstruction',
  templateUrl: 'areaconstruction.html',
})

export class AreaconstructionPage {
  items:any;
  sitename: any;
  folders = [
    // {
    //   "firstName": "Anil's company",
    //   "lastName": "Benton's Home",
    //   "username": "mbenton",
    //   "age": "10",
    //   "teamId": 1
    // },
    // {
    //   "firstName": "Anand's Home",
    //   "lastName": "Benton",
    //   "username": "mbenton",
    //   "age": "10",
    //   "teamId": 1
    // },
    // {
    //   "firstName": "Vishal's company",
    //   "lastName": "Benton",
    //   "username": "mbenton",
    //   "age": "10",
    //   "teamId": 1
    // }, 
    // {
    //   "firstName": "Jiya's Home",
    //   "lastName": "Benton",
    //   "username": "mbenton",
    //   "age": "10",
    //   "teamId": 1
    // },
    // {
    //   "firstName": "Morgan's company",
    //   "lastName": "Benton",
    //   "username": "mbenton",
    //   "age": "10",
    //   "teamId": 1
    // },
    // {
    //   "firstName": "Kelsey's company",
    //   "lastName": "Banks",
    //   "username": "kbanks",
    //   "age": "5",
    //   "teamId": 2
    // },
    // {
    //   "firstName": "Jessica's Home",
    //   "lastName": "Martinez",
    //   "username": "jmartinez",
    //   "age": "1",
    //   "teamId": 3
    // },
    // {
    //   "firstName": "Maggie's company",
    //   "lastName": "Walker",
    //   "username": "mwalker",
    //   "age": "10",
    //   "teamId": 4
    // }
  ];
    displaydata:any;

  constructor(public navCtrl: NavController,
    public dropbox: DropboxProvider,
    public loadingCtrl: LoadingController,
     public navParams: NavParams) 
  {
    this.sitename =  this.navParams.get('site_name');
    this.getDropboxData()
  }

  getDropboxData() 
  {
    this.dropbox.setAccessToken("g7iHQVRCiVAAAAAAAAAACmAkAuB7W8O9xcl_KtcZazx48whie18H8rMbk4sKY1dV");
    let loading = this.loadingCtrl.create({
      content: 'Syncing from Dropbox...'
    });
    loading.present();
    this.dropbox.getFolders(this.sitename).subscribe(data => {
      this.folders = data.entries; 
      console.log('folders new=> ',  this.folders); 
  
      this.sortByKey(this.folders, 'name').then(async (data) => {
        console.log("sort Data => ", data);
        await this.firstLatter();
        await this.initializeItems(); 
         this.displaydata =this.folders;
      })  
      loading.dismiss();
    }, (err) => {
      console.log(err);
    });
  }

  async firstLatter() 
  {
    let people = []
    let firstLetter = ""
    for (let i in this.folders) 
    {
      let currentLetter = this.folders[i].name[0].toUpperCase()
      if (currentLetter != firstLetter) {
        firstLetter = "" + currentLetter
        people.push({ index: firstLetter })
      }
      people.push(this.folders[i])
    }
    this.folders = people;
    await console.log('players', this.folders)
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad AreaconstructionPage');
  }
  async sortByKey(array, key) {

    return array.sort(function (a, b) 
    {
      var x = a[key];
      var y = b[key];
      return ((x < y) ? -1 : ((x > y) ? 0 : 1));
    });
  }

  initializeItems() {
    this.items = this.folders;
  }

  getItems(ev: any) {
    // Reset items back to all of the items
    this.initializeItems();

    // set val to the value of the searchbar
    const val = ev.target.value;

    // if the value is an empty string don't filter the items
    if (val && val.trim() != '') {
      this.items = this.items.filter((item) => {
        if(item['name']){
          // console.log('item if => ', item);
          return (item.name.toLowerCase().indexOf(val.toLowerCase()) > -1);
        }else {
          return (item.index.toLowerCase().indexOf(val.toLowerCase()) > -1);
        }
      })
    }
   this.displaydata = this.items;
  }
  updateCucumber(e){
    console.log();
  }
  goToImagepage (path){
    this.navCtrl.push("ImagelistPage", {
      path: path,
    });
  }
}
