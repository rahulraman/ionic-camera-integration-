import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AreaconstructionPage } from './areaconstruction';

@NgModule({
  declarations: [
    AreaconstructionPage,
  ],
  imports: [
    IonicPageModule.forChild(AreaconstructionPage),
  ],
})
export class AreaconstructionPageModule {}
