import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

/*
  Generated class for the LocalstorageProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class LocalstorageProvider {

  constructor(public http: HttpClient) 
  {

    console.log('Hello LocalstorageProvider Provider');

  }

  storeCurrentLocation(lat , lng) 
  {
    window.localStorage.setItem('lat',lat);
    window.localStorage.setItem('lng',lng);
  }
}
