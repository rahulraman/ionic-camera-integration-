import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, ResponseContentType } from '@angular/http';
import 'rxjs/add/operator/map';
import { DomSanitizer } from '@angular/platform-browser';
import { LoadingController } from 'ionic-angular';

@Injectable()
export class DropboxProvider {

  accessToken: any = 'g7iHQVRCiVAAAAAAAAAACmAkAuB7W8O9xcl_KtcZazx48whie18H8rMbk4sKY1dV';
  folderHistory: any = [];
 
  constructor(public http: Http,
    public loadingCtrl: LoadingController,
     private sanitizer: DomSanitizer) 
     {}

  setAccessToken(token) {
    this.accessToken = token; 
  }

  getUserInfo(){
    let headers = new Headers();
    headers.append('Authorization', 'Bearer ' + this.accessToken);
    headers.append('Content-Type', 'application/json');
    // return this.http.post('https://api.dropboxapi.com/2-beta-2/users/get_current_account', "null", {headers: headers})
    return this.http.post('https://api.dropboxapi.com/2/users/get_current_account', "null", {headers: headers})
      .map(res => res.json());
  } 

  getFolders(path?){
    let headers = new Headers();
    headers.append('Authorization', 'Bearer ' + this.accessToken);
    headers.append('Content-Type', 'application/json');
    let folderPath;
    if(typeof(path) == "undefined" || !path){
      folderPath = {
        path: ""
      };
    } else {
      folderPath = {
        path: path
      };
      if(this.folderHistory[this.folderHistory.length - 1] != path)
      {
        this.folderHistory.push(path);
      }
    } 
    return this.http.post('https://api.dropboxapi.com/2-beta-2/files/list_folder', JSON.stringify(folderPath), {headers: headers})
      .map(res => res.json());
  }

  goBackFolder(){
    if(this.folderHistory.length > 0){
      this.folderHistory.pop();
      let path = this.folderHistory[this.folderHistory.length - 1];
      return this.getFolders(path);
    }
    else {
      return this.getFolders();
    }
  }

  downloadFile(path_lower) 
  {
     let headers = new Headers();
    let url = 'https://content.dropboxapi.com/2/files/download';
    headers.append('Authorization', 'Bearer ' + this.accessToken);
    headers.append('Dropbox-API-Arg', `{"path":"${path_lower}"}`);
    let options = new RequestOptions({ headers: headers , responseType: ResponseContentType.ArrayBuffer}); //responseType added here
    return this.http.get(url, options)
      .map(res => {
        return res;
      }) 
      .map(resp => {
        console.log(resp);
        var urlCreator = window.URL;
        const toDownload: Blob = new Blob([resp.arrayBuffer()], {type: 'application/octet-stream'}); //and this type:
        return  this.sanitizer.bypassSecurityTrustUrl(urlCreator.createObjectURL(toDownload));
      })
  } 
 
  uploadFile(data: any , path ) {
    let headers = new Headers();
    let mydata: any;
    headers.append('Authorization', 'Bearer g7iHQVRCiVAAAAAAAAAACmAkAuB7W8O9xcl_KtcZazx48whie18H8rMbk4sKY1dV');
    headers.append('Content-Type', 'application/octet-stream');
    headers.append('Dropbox-API-Arg', `{"path":"${path}/img.png","autorename":true,"mode":{".tag":"add"},"mute":false}`);
    return  this.http.post('https://content.dropboxapi.com/2/files/upload', data, { headers: headers })
    .map(
      res => res.json());
  }

  deleteFile(filePath) 
  {
    let headers = new Headers();
    let body ;
    body = {
      "path": filePath
    }
   let url = 'https://api.dropboxapi.com/2/files/delete_v2';
   headers.append('Authorization', 'Bearer g7iHQVRCiVAAAAAAAAAACmAkAuB7W8O9xcl_KtcZazx48whie18H8rMbk4sKY1dV');
   headers.append('Content-Type', 'application/json ');
   let options = new RequestOptions({ headers: headers }); //responseType added here
   return this.http.post(url, body ,options)
     .map(res =>
      {
       return res;
     })
 }
 createFolder(filePath) 
 {
   let headers = new Headers();
   let body ;
   body = {
     "path": filePath
   }
  let url = 'https://api.dropboxapi.com/2/files/create_folder_v2 ';
  headers.append('Authorization', 'Bearer g7iHQVRCiVAAAAAAAAAACmAkAuB7W8O9xcl_KtcZazx48whie18H8rMbk4sKY1dV');
  headers.append('Content-Type', 'application/json ');
  let options = new RequestOptions({ headers: headers }); //responseType added here
  return this.http.post(url, body ,options)
    .map(res =>
     {
      return res;
    })
}
}
